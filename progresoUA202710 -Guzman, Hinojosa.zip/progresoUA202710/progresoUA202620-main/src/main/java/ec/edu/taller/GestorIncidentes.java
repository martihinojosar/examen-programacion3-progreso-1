package ec.edu.taller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class GestorIncidentes {

    private PriorityQueue<IncidenteSeguridad> colaIncidentes;
    private int capacidadMaxima;

    public GestorIncidentes(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
        this.colaIncidentes = new PriorityQueue<>(
                Comparator.comparingInt(IncidenteSeguridad::getPrioridad));
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public boolean registrarIncidente(IncidenteSeguridad incidente) {
        if (incidente == null) return false;
        if (incidente.getCodigo() == null || incidente.getCodigo().trim().isEmpty()) return false;
        if (existeIncidente(incidente.getCodigo())) return false;
        if (colaIncidentes.size() >= capacidadMaxima) return false;
        return colaIncidentes.offer(incidente);
    }

    public boolean existeIncidente(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) return false;
        for (IncidenteSeguridad inc : colaIncidentes) {
            if (inc.getCodigo().equalsIgnoreCase(codigo)) {
                return true;
            }
        }
        return false;
    }

    public IncidenteSeguridad consultarSiguienteIncidente() {
        return colaIncidentes.peek();
    }

    public IncidenteSeguridad atenderSiguienteIncidente() {
        IncidenteSeguridad incidente = colaIncidentes.poll();
        if (incidente != null) {
            incidente.setEstado("ATENDIDO");
        }
        return incidente;
    }

    public int contarIncidentesPendientes() {
        return colaIncidentes.size();
    }

    public int consultarEspaciosDisponibles() {
        return capacidadMaxima - colaIncidentes.size();
    }

    public List<IncidenteSeguridad> listarIncidentes() {
        PriorityQueue<IncidenteSeguridad> copiaCola = new PriorityQueue<>(colaIncidentes);
        List<IncidenteSeguridad> listaOrdenada = new ArrayList<>();
        while (!copiaCola.isEmpty()) {
            listaOrdenada.add(copiaCola.poll());
        }
        return listaOrdenada;
    }
}