package ec.edu.taller;

import javax.swing.*;
import java.util.List;

public class Ventana extends JFrame {
    private JPanel panelPrincipal;
    private JTabbedPane tabs;
    private JLabel lblTitulo;
    private JTextField txtCodigo;
    private JComboBox<String> cmbTipo;
    private JTextArea txtDescripcion;
    private JSpinner spnPrioridad;
    private JLabel lblEstadoInicial;
    private JButton btnRegistrar;
    private JLabel lblPendientes;
    private JLabel lblDisponibles;
    private JLabel lblCapacidad;
    private JLabel lblCodigo;
    private JLabel lblPrioridad;
    private JLabel lblTIpo;
    private JLabel lblEstado;
    private JLabel lblDescripcion;
    private JButton btnSiguiente;
    private JButton btnListar;
    private JButton btnAtender;
    private JTextArea txtLista;

    private final GestorIncidentes gestor = new GestorIncidentes(10);

    public Ventana() {
        setTitle("Gestión de Incidentes de Seguridad");
        setContentPane(panelPrincipal);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 450);
        setLocationRelativeTo(null);

        // Configuración inicial de componentes
        cmbTipo.setModel(new DefaultComboBoxModel<>(new String[]{
                "Phishing", "Malware", "Acceso no autorizado", "Fuga de datos", "DDoS", "Otro"
        }));
        spnPrioridad.setModel(new SpinnerNumberModel(1, 1, 5, 1)); // 1 = más urgente
        lblEstadoInicial.setText("PENDIENTE");
        txtLista.setEditable(false);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);

        // Listeners
        btnRegistrar.addActionListener(e -> registrar());
        btnSiguiente.addActionListener(e -> consultarSiguiente());
        btnAtender.addActionListener(e -> atender());
        btnListar.addActionListener(e -> listar());

        // Datos de prueba
        cargarDatosPrueba();
        actualizarContadores();
        listar();
    }

    private void registrar() {
        String codigo = txtCodigo.getText().trim();
        String descripcion = txtDescripcion.getText().trim();

        if (codigo.isEmpty() || descripcion.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa el código y la descripción.",
                    "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (gestor.existeIncidente(codigo)) {
            JOptionPane.showMessageDialog(this, "Ya existe un incidente con ese código.",
                    "Código duplicado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (gestor.consultarEspaciosDisponibles() <= 0) {
            JOptionPane.showMessageDialog(this, "La cola está llena.",
                    "Sin espacio", JOptionPane.WARNING_MESSAGE);
            return;
        }

        IncidenteSeguridad incidente = new IncidenteSeguridad(
                codigo,
                (String) cmbTipo.getSelectedItem(),
                descripcion,
                (Integer) spnPrioridad.getValue());

        if (gestor.registrarIncidente(incidente)) {
            JOptionPane.showMessageDialog(this, "Incidente registrado correctamente.");
            txtCodigo.setText("");
            txtDescripcion.setText("");
            spnPrioridad.setValue(1);
            cmbTipo.setSelectedIndex(0);
            actualizarContadores();
            listar();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo registrar el incidente.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void consultarSiguiente() {
        IncidenteSeguridad sig = gestor.consultarSiguienteIncidente();
        if (sig == null) {
            JOptionPane.showMessageDialog(this, "No hay incidentes pendientes.");
        } else {
            JOptionPane.showMessageDialog(this,
                    "Siguiente a atender:\n" + sig + "\n\n" + sig.getDescripcion());
        }
    }

    private void atender() {
        IncidenteSeguridad atendido = gestor.atenderSiguienteIncidente();
        if (atendido == null) {
            JOptionPane.showMessageDialog(this, "No hay incidentes pendientes.");
        } else {
            JOptionPane.showMessageDialog(this, "Incidente atendido:\n" + atendido);
        }
        actualizarContadores();
        listar();
    }

    private void listar() {
        List<IncidenteSeguridad> lista = gestor.listarIncidentes();
        if (lista.isEmpty()) {
            txtLista.setText("No hay incidentes pendientes.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (IncidenteSeguridad inc : lista) {
            sb.append(inc).append("\n");
        }
        txtLista.setText(sb.toString());
    }

    private void actualizarContadores() {
        lblPendientes.setText("Pendientes: " + gestor.contarIncidentesPendientes());
        lblDisponibles.setText("Espacios disponibles: " + gestor.consultarEspaciosDisponibles());
        lblCapacidad.setText("Capacidad máxima: " + gestor.getCapacidadMaxima());
    }

    private void cargarDatosPrueba() {
        gestor.registrarIncidente(new IncidenteSeguridad("INC-001", "Phishing",
                "Correo sospechoso reportado por el área de finanzas", 3));
        gestor.registrarIncidente(new IncidenteSeguridad("INC-002", "Malware",
                "Equipo del laboratorio infectado con ransomware", 1));
        gestor.registrarIncidente(new IncidenteSeguridad("INC-003", "Acceso no autorizado",
                "Intento de ingreso al servidor de base de datos", 2));
        gestor.registrarIncidente(new IncidenteSeguridad("INC-004", "Fuga de datos",
                "Archivo con datos de estudiantes compartido públicamente", 1));
        gestor.registrarIncidente(new IncidenteSeguridad("INC-005", "DDoS",
                "Saturación del portal web institucional", 2));
        gestor.registrarIncidente(new IncidenteSeguridad("INC-006", "Phishing",
                "Enlace falso de actualización de contraseña", 4));
        gestor.registrarIncidente(new IncidenteSeguridad("INC-007", "Otro",
                "Pérdida de un dispositivo USB corporativo", 5));
        gestor.registrarIncidente(new IncidenteSeguridad("INC-008", "Malware",
                "Antivirus detectó troyano en equipo de secretaría", 3));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ventana().setVisible(true));
    }
}